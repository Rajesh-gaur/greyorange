 <footer id="footer">
     <div class="footer-top">
      <div class="container">
	  
        <div class="get-in-touch text-center">
	     <h2><strong>Need Some Help? </strong>Lets Connect</h2>
		 <a class="cta-btn btn" href="#">Get in touch</a>
	    </div>	  
	  </div>
	 </div>
	 <div class="container footer-bottoms">
	   <div class="row">
	 
	  <div class="col-sm-4">	   
	   <div class="copyright">Copyright © 2018 <strong>GREYORANGE.</strong> All Rights Reserved</div>
      </div>  
	  
	  <div class="col-sm-6">	
	     <ul class="footer-links">
		   <li><a href="#">Solutions</a></li> 
		   <li><a href="#">Support</a></li> 
		   <li><a href="#">Contact us</a></li> 
		   <li><a href="#">About us</a></li> 
		   <li><a href="#">Press</a></li> 
		   <li><a href="#">Events</a></li> 
		   <li><a href="#">Partners</a></li> 
		   <li><a href="#">Careers</a></li> 
		   <li><a href="case.php">Case Study</a></li> 
		 </ul>
      </div>  
	  
	  <div class="col-sm-2 text-right">	   
	      <img src="images/facebook.png" alt="facebook" />
	      <img src="images/twitter.png" alt="twitter" />
	      <img src="images/linkdin.png" alt="linkdin" />
	      <img src="images/youtube.png" alt="youtube" />
      </div>
	  
	   </div>
	 </div>
   </footer>
   <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
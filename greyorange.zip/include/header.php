
 <header id="header">
    <div class="container-fluid">
      <div id="logo" class="pull-left">
        <h1 class="head-logo"><a href="index.php" class="scrollto"><img src="images/greyorange-logo.png" alt="greyorange logo" /></a></h1>
		 <h1 class="scroll-logo"><a href="index.php" class="scrollto"><img src="images/grey-orange-grey.png" alt="greyorange logo" /></a></h1>
      </div>      
	  <div class="head-menu">
	    <ul>
		   <li><a href="#">Products</a></li>
		   <li><a href="#">Support</a></li>
		   <li><a href="#">Contact Us</a></li>
		</ul>
	  </div>
	  
	 <div class="wrapper">
	
            <!-- Sidebar Holder -->
            <nav id="sidebar">
			  <div id="sidebarCollapse" class="btn">
				  <img src="images/nav.png" class="opan-arrow" />
				  <img src="images/nav-home.png" class="opan-home" />
				  <img src="images/left-arrow.png" class="cancel-arrow" />
		        </div>
			  <div class="menu-block">	
                <ul class="list-unstyled components">
				   <p>vcbbbbbbvbcbvvbc</p>				   
				   <li> <a href="#">About</a></li>
                    <li class="active">
                        <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Press</a>
                        <ul class="collapse list-unstyled" id="homeSubmenu">
                            <li><a href="#">Press Release</a></li>
                            <li><a href="#">News</a></li>
                            <li><a href="#">Media Kit</a></li>
                        </ul>
                    </li>
                    <li>
                     
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Events</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li><a href="#">Events 1</a></li>
                            <li><a href="#">Events 2</a></li>
                            <li><a href="#">Events 3</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Partners</a></li>
                    <li><a href="#">Careers</a></li>
                    <li>
                        <a href="#">Case Study</a>
                    </li>
                </ul>
             </div>
                
            </nav>
		</div>	
    </div>	
  </header><!-- #header -->

 <div class="customer">	
	    <article id="clients" class="wow fadeInUp">
		  <div class="container">
		   <div class="row">		   
		    <div class="ket-title col-lg-1 col-md-2">Key Customers</div>			
		     <div class="client-block col-lg-10 col-md-10"> 
				<div class="owl-carousel clients-carousel">
				  <img src="images/flipkart.png" alt="flipkart">
				  <img src="images/myntra.png" alt="myntra">
				  <img src="images/jabong.png" alt="jabong">
				</div>
			  </div>			
			 <div class="viewall col-lg-1 col-md-2"> <a href="javascript:;">View All</a></div>			 
		   </div>
		 </div>
		</article><!-- #clients -->
	</div> 	  